#!/usr/bin/env bash

set -euo pipefail

source "$(dirname "$0")/config.sh"

parse_build_args "$@"

##############################################################################
# OpenMPI Installation
##############################################################################

NAME="openmpi"
VERSION="$MPI_VERSION"
INSTALL="$(install_dir "$NAME" "$VERSION")"

##############################################################################
# Command-line options
##############################################################################

while [[ $# -gt 0 ]]; do
    case "$1" in
        --module-only)
            MODULE_ONLY=true
            ;;
        --force)
            FORCE=true
            ;;
        *)
            echo "Unknown option: $1"
            echo
            echo "Usage:"
            echo "  $0 [--module-only] [--force]"
            exit 1
            ;;
    esac
    shift
done

##############################################################################
# Prerequisites
##############################################################################

require gcc
require g++
require gfortran
require make

##############################################################################
# Build and install
##############################################################################

if ! $MODULE_ONLY; then

    if installed "$INSTALL/bin/mpicc" && ! $FORCE; then
        echo "OpenMPI $VERSION already installed."

    else

        if $FORCE; then
            rm -rf "$INSTALL"
        fi

        ARCHIVE="openmpi-$VERSION.tar.gz"
        URL="https://download.open-mpi.org/release/open-mpi/v5.0/$ARCHIVE"

        echo "Downloading OpenMPI..."
        download "$URL" "$ARCHIVE"

        echo
        echo "Extracting..."
        extract "$ARCHIVE" "openmpi-$VERSION"

        echo
        echo "Preparing build directory..."

        rm -rf "$BUILD/openmpi-$VERSION"
        mkdir -p "$BUILD/openmpi-$VERSION"

        cd "$BUILD/openmpi-$VERSION"

        echo
        echo "Configuring..."

        "$SRC/openmpi-$VERSION/configure" \
            --prefix="$INSTALL"

        echo
        echo "Building..."

        # make -j"$(nproc)"
        make -j"$JOBS"

        echo
        echo "Installing..."

        make install

    fi

fi

##############################################################################
# Verify installation
##############################################################################

if ! installed "$INSTALL/bin/mpicc"; then
    echo
    echo "ERROR: OpenMPI installation failed."
    exit 1
fi

##############################################################################
# Write module
##############################################################################

write_module compiler "$NAME" "$VERSION" "$INSTALL" '
family("mpi")
'

##############################################################################
# Summary
##############################################################################

echo
echo "=============================================================="
echo " OpenMPI $VERSION"
echo "=============================================================="
echo
echo "Installation:"
echo "  $INSTALL"
echo
echo "Module:"
echo "  $MODULES/Compiler/$COMPILER/$COMPILER_VERSION/$NAME/$VERSION.lua"
echo
echo "Done."