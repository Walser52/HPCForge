#!/usr/bin/env bash

set -euo pipefail

source "$(dirname "$0")/config.sh"

parse_build_args "$@"

##############################################################################
# LibXC Installation
##############################################################################

NAME="libxc"
VERSION="$LIBXC_VERSION"
INSTALL="$(install_dir "$NAME" "$VERSION")"

##############################################################################
# Prerequisites
##############################################################################

require "$CC"
require "$FC"
require cmake
require make

##############################################################################
# Build and install
##############################################################################

if ! $MODULE_ONLY; then

    if already_installed "lib/libxc.so"; then
        echo "LibXC $VERSION already installed."

    else

        if $FORCE; then
            rm -rf "$INSTALL"
        fi

        ARCHIVE="libxc-$VERSION.tar.gz"
        URL="https://gitlab.com/libxc/libxc/-/archive/$VERSION/$ARCHIVE"

        echo "Downloading LibXC..."
        download "$URL" "$ARCHIVE"

        echo
        echo "Extracting..."
        extract "$ARCHIVE" "libxc-$VERSION"

        rm -rf "$BUILD/libxc-$VERSION"
        mkdir -p "$BUILD/libxc-$VERSION"

        cd "$BUILD/libxc-$VERSION"

        echo
        echo "Configuring..."

        cmake \
            -DCMAKE_INSTALL_PREFIX="$INSTALL" \
            -DCMAKE_BUILD_TYPE=Release \
            -DCMAKE_C_COMPILER="$CC" \
            -DCMAKE_Fortran_COMPILER="$FC" \
            -DBUILD_SHARED_LIBS=ON \
            "$SRC/libxc-$VERSION"

        echo
        echo "Building..."

        # make -j"$(nproc)"
        make -j"$JOBS"
        
        echo
        echo "Installing..."

        make install

    fi

fi

##############################################################################
# Verify installation
##############################################################################


if ! library_exists "libxc.so"; then
    echo
    echo "ERROR: LibXC installation failed."
    exit 1
fi
# if ! installed "$INSTALL/lib/libxc.so"; then
#     echo
#     echo "ERROR: LibXC installation failed."
#     exit 1
# fi

##############################################################################
# Module
##############################################################################

write_module compiler "$NAME" "$VERSION" "$INSTALL"

##############################################################################
# Summary
##############################################################################

echo
echo "=============================================================="
echo " LibXC $VERSION"
echo "=============================================================="

echo
echo "Installation:"
echo "  $INSTALL"

echo
echo "Module:"
echo "  $MODULES/Compiler/$COMPILER/$COMPILER_VERSION/$NAME/$VERSION.lua"

echo
echo "Done."