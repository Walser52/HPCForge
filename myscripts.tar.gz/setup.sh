#!/usr/bin/env bash

source /usr/share/lmod/lmod/init/bash

# Remove any previous personal module tree (safe if absent)
module unuse "$HOME/modules/Core" 2>/dev/null || true

# Add the root of the hierarchy
module use "$HOME/modules/Core"